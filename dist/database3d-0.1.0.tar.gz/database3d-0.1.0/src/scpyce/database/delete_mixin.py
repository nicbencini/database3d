

class DeleteMixin:

    pass